package com.example.av1imc

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_history.*
import kotlinx.android.synthetic.main.activity_result.*
import java.util.*

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        //pra salvar na mémoria
        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)
        var hist = "KeyHist"
        var histList = sh.getString(hist,"")
        var tkn = StringTokenizer(histList.toString(),";")

        while(tkn.hasMoreTokens()){
            var peso = tkn.nextToken()
            var alt = tkn.nextToken()
            var imc = peso!!.toDouble() /(alt!!.toDouble() * alt!!.toDouble())
            var conta = ("IMC = "+peso.toString()+"kg/("+alt.toString()+"m*"+alt.toString()+"m) = "+String.format("%.2f",imc)+"kg/m2")

            txtLista.append(conta.toString()+"\n")

            if (imc < 18.5){
                txtLista.append("Classificação:Magreza"+"\n")
                txtLista.append("Grau:0"+"\n")
            }
            else if ((imc > 18.5) && (imc < 24.9)){
                txtLista.append("Classificação:Normal"+"\n")
                txtLista.append("Grau:0"+"\n")
            }
            else if ((imc > 25.0) && (imc < 29.9)){
                txtLista.append("Classificação:Sobrepeso"+"\n")
                txtLista.append("Grau:1"+"\n")
            }
            else if ((imc > 30.0) && (imc < 39.9)){
                txtLista.append("Classificação:Obesidade"+"\n")
                txtLista.append("Grau:2"+"\n")
            }
            else{
                txtLista.append("Classificação:Obesidade Grave"+"\n")
                txtLista.append("Grau:3"+"\n")
            }
                txtLista.append("*******************************************"+"\n")
        }


        btVoltarHistory.setOnClickListener { v: View? ->
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
    }
}