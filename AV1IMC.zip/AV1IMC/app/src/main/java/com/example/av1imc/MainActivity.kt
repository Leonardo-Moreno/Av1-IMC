package com.example.av1imc

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.StringBuilder

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //pra salvar na mémoria
        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)
        btLimpar.setOnClickListener {v: View? ->
            txtAltura.text.clear()
            txtPeso.text.clear()
        }
        btCalcular.setOnClickListener { v: View?->
            if (!(txtAltura.text.isNullOrEmpty()) && !(txtPeso.text.isNullOrEmpty())){
                var hist = "KeyHist"
                var key = "KeyLast"

                val str = StringBuilder()
                str.append(txtPeso.text.toString()).append(";")
                str.append(txtAltura.text.toString()).append(";")
                sh.edit().putString(key.toString(),str.toString()).apply()

                var histLista = sh.getString(hist,"")

                val str2 = StringBuilder()
                str2.append(histLista.toString()).append(";")
                str2.append(txtPeso.text.toString()).append(";")
                str2.append(txtAltura.text.toString()).append(";")

                sh.edit().putString(hist.toString(),str2.toString()).apply()
                val intent = Intent(this,ResultActivity::class.java)
                startActivity(intent)

            }
            else{
                Toast.makeText(this,"Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            }
        }
        btHist.setOnClickListener { v: View? ->
            val intent = Intent(this,HistoryActivity::class.java)
            startActivity(intent)
        }

    }

}